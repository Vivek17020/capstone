# Frontend fix — wiring Angular client to Spring Boot backend

## Files in this bundle

Drop these into your existing `client/` folder, replacing the originals:

```
client/src/environments/environment.ts        (replace)
client/src/environments/environment.prod.ts   (replace)
client/src/index.html                         (replace — removes duplicate <base> and bad base-rewrite script)
client/proxy.conf.json                        (new — optional dev proxy)
```

## Two ways to run it locally

### Option A — Direct calls to backend (simplest)

`environment.ts` is shipped with `apiUrl: 'http://localhost:8080'`.

1. Start the backend:
   ```
   cd server
   mvn spring-boot:run
   ```
   It listens on `http://localhost:8080`.

2. Start the Angular app (already on port 3000 per your `package.json`):
   ```
   cd client
   npm install
   npm start
   ```

   Open `http://localhost:3000`.

CORS is already enabled on every controller (`@CrossOrigin(origins = "*")`),
so cross-origin requests from `:3000` to `:8080` will work.

### Option B — Dev proxy (no CORS at all)

Use the included `proxy.conf.json` so the Angular dev server forwards
`/api/*` to the Spring Boot server. Calls become same-origin from the browser.

1. Edit `client/src/environments/environment.ts` and set:
   ```ts
   apiUrl: '',
   ```

2. Update the `start` script in `client/package.json` to:
   ```json
   "start": "ng serve --disable-host-check --port 3000 --proxy-config proxy.conf.json"
   ```

3. Run backend (`mvn spring-boot:run`) and `npm start` as in Option A.

## What was broken

1. **`environment.ts` apiUrl** was
   `window.location.href.replace(/5000\/.*$/, "3000")` — that regex never
   matches `localhost:3000` or `localhost:8080`, so `apiUrl` ended up being
   the full current page URL, and every backend call hit the Angular dev
   server instead of Spring Boot.

2. **`environment.prod.ts`** had no `apiUrl` field at all, so the production
   bundle wouldn't even compile against `HttpService`.

3. **`index.html`** had two `<base href="/">` tags and a script that
   rewrote `<base>` based on a `5000/` path segment. That breaks Angular
   routing on any normal localhost or hosted setup.

## Backend sanity checks (Java side, no changes shipped)

- `server/src/main/resources/application.properties` does **not** set
  `server.port`, so Spring Boot listens on `8080`. If you want to change
  it, add `server.port=8080` explicitly.
- `JwtUtil` must have a configured secret (env var or hardcoded in the
  class) — verify before first login.
- `SecurityConfig` permits `POST /api/auth/register` and `/api/auth/login`
  unauthenticated; everything else under `/api/**` requires a valid Bearer
  JWT, which `HttpService` already attaches via `Authorization: Bearer ...`.

## Endpoint map (what the frontend hits → what the backend serves)

| Frontend call                              | Backend route                                |
|--------------------------------------------|----------------------------------------------|
| POST `/api/auth/login`                     | `AuthController#login`                       |
| POST `/api/auth/register`                  | `AuthController#register`                    |
| GET  `/api/auth/user`                      | `AuthController#getLoggedInUser`             |
| GET/POST/PUT `/api/flights[...]`           | `FlightsController`                          |
| GET  `/api/flights/search`                 | `FlightsController#searchFlights`            |
| GET  `/api/flights/source|destination/suggest` | `FlightsController#suggestSource/Destination` |
| GET  `/api/flights/{id}/check-availability`| `FlightsController#checkAvailability`        |
| GET  `/api/seats/flights/{id}/seats`       | `SeatController#getSeatsByFlight`            |
| POST `/api/booking/book-seats`             | `BookingsController#bookSeats`               |
| GET  `/api/booking/bookings`               | `BookingsController#getMyBookings`           |
| GET  `/api/booking/bookingList`            | `BookingsController#getAllBookings` (ADMIN)  |
| PUT  `/api/booking/{id}/status`            | `BookingsController#updateBookingStatus`     |
| GET  `/api/booking/ticket/{id}`            | `BookingsController#downloadTicket` (PDF)    |
| POST `/api/pilot/schedule/admin/assign-pilot` | `FlightScheduleController#assignPilot`    |
| GET  `/api/pilot/schedule[/users|/scheduleUser]` | `FlightScheduleController` (list / mine)|
| PUT  `/api/pilot/schedule/{id}/status`     | `FlightScheduleController#updateStatus`      |

All endpoints align with the existing `HttpService` in
`client/src/services/http.service.ts` — no service code changes needed.
