// Development environment.
// Spring Boot backend runs on http://localhost:8080 by default.
// If you start the dev server with the proxy (npm start), set apiUrl to ''
// so requests go to the Angular dev server (port 3000) and are proxied to 8080.
export const environment = {
  production: false,
  // Direct mode (no proxy). Requires backend CORS to allow http://localhost:3000.
  apiUrl: 'http://localhost:8080',
  // Proxy mode: uncomment the next line and comment the one above
  // apiUrl: '',
};
