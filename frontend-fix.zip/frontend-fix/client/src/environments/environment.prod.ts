// Production environment.
// Set apiUrl to wherever your Spring Boot server is deployed.
// If the Angular app is served from the same origin/host as the backend,
// leave apiUrl as '' so requests are made as same-origin (e.g. /api/...).
export const environment = {
  production: true,
  apiUrl: '',
};
